// server.js

const express = require("express");
const session = require("express-session"); // セッションミドルウェアをインポート
const fs = require("fs");
const path = require("path");

const app = express();

// --- ミドルウェア設定 ---
app.use(express.json());
app.use(express.static("public"));

// セッションミドルウェアの設定
app.use(
  session({
    secret: "your-secret-key-12345", // 任意の秘密鍵を設定
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false }, // HTTPSではないのでfalseに設定
  })
);

// --- ルートの読み込み ---
const authRoutes = require("./routes/auth");
const postRoutes = require("./routes/posts");

// --- ルートの登録 ---
app.use("/api/auth", authRoutes);
app.use("/api/posts", postRoutes);

// サーバー起動
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
