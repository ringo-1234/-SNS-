// public/js/app.js (ログインページ用)

async function login() {
  const name = document.getElementById("name").value;
  const password = document.getElementById("password").value;
  const msgDiv = document.getElementById("message");

  if (!name || !password) {
    msgDiv.textContent = "名前とパスワードを入力してください";
    return;
  }

  try {
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ name, password }),
    });

    const data = await res.json();
    console.log("レスポンス", data);

    if (data.success) {
      msgDiv.textContent = `ようこそ、${data.user.name} さん！ タイムラインに移動します...`;
      // ログイン成功後、タイムラインページにリダイレクト
      window.location.href = "posts.html";
    } else {
      msgDiv.textContent = `エラー: ${data.error}`;
    }
  } catch (e) {
    console.error(e);
    msgDiv.textContent = "通信エラーが発生しました";
  }
}
