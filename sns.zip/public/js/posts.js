// public/js/posts.js (タイムラインページ用)

let currentUser = null;

// ページ読み込み時に実行
window.onload = () => {
  checkAuth();
};

// 認証状態の確認
async function checkAuth() {
  try {
    const res = await fetch("/api/auth/me");
    const data = await res.json();
    if (data.success) {
      currentUser = data.user;
      document.getElementById(
        "userNameDisplay"
      ).textContent = `こんにちは、${currentUser.name}さん！`;
      loadPosts();
    } else {
      // 認証されていない場合はログインページへ
      window.location.href = "index.html";
    }
  } catch (e) {
    console.error("認証状態の確認中にエラー:", e);
    window.location.href = "index.html";
  }
}

// ログアウト処理
async function logout() {
  try {
    await fetch("/api/auth/logout", { method: "POST" });
    window.location.href = "index.html";
  } catch (e) {
    console.error("ログアウト中にエラー:", e);
  }
}

// 投稿送信
async function submitPost() {
  const content = document.getElementById("postContent").value;
  if (!content) {
    alert("投稿内容が空です");
    return;
  }
  if (!currentUser) {
    alert("ログインしていません");
    window.location.href = "index.html";
    return;
  }

  try {
    const res = await fetch("/api/posts", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        userName: currentUser.name,
        content,
      }),
    });
    const data = await res.json();
    if (data.success) {
      document.getElementById("postContent").value = "";
      loadPosts();
    } else {
      alert("投稿に失敗しました: " + data.error);
    }
  } catch (e) {
    console.error("投稿送信エラー:", e);
    alert("通信エラーが発生しました");
  }
}

// 投稿一覧を取得
async function loadPosts() {
  try {
    const res = await fetch("/api/posts");
    const posts = await res.json();
    const timeline = document.getElementById("timeline");
    timeline.innerHTML = "";

    posts.reverse().forEach((post) => {
      const postDiv = document.createElement("div");
      postDiv.className = "bg-gray-50 p-4 rounded-xl shadow-sm mb-4";
      postDiv.innerHTML = `
        <div class="flex justify-between items-start mb-2">
          <div>
            <strong class="text-blue-600 font-bold">${post.userName}</strong>
            <span class="text-xs text-gray-500 ml-2">${new Date(
              post.timestamp
            ).toLocaleString()}</span>
          </div>
          <button onclick="toggleLike(${
            post.id
          })" class="text-gray-400 hover:text-red-500 transition-colors duration-200">
            <i class="${
              currentUser && post.likes.includes(currentUser.name)
                ? "fas fa-heart text-red-500"
                : "far fa-heart"
            }"></i>
            <span id="like-count-${post.id}" class="ml-1">${
        post.likes.length
      }</span>
          </button>
        </div>
        <p class="text-gray-800 mb-4 whitespace-pre-wrap">${post.content}</p>
        
        <div class="replies-section border-t border-gray-200 pt-4 mt-4">
          <h4 class="text-sm font-semibold text-gray-600 mb-2">リプライ (${
            post.replies.length
          })</h4>
          <div id="replies-${post.id}">
            ${post.replies
              .map(
                (reply) => `
              <div class="bg-gray-100 p-3 rounded-lg mb-2 text-sm">
                <strong class="text-purple-600">${reply.userName}</strong>: ${
                  reply.content
                }
                <small class="text-gray-400 block">${new Date(
                  reply.timestamp
                ).toLocaleString()}</small>
              </div>
            `
              )
              .join("")}
          </div>
          <div class="mt-4 flex">
            <input type="text" id="reply-input-${
              post.id
            }" class="flex-1 px-3 py-2 rounded-l-lg border-t border-b border-l focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="リプライを投稿...">
            <button onclick="submitReply(${
              post.id
            })" class="bg-blue-500 text-white px-4 py-2 rounded-r-lg hover:bg-blue-600 transition duration-300">
              <i class="fas fa-reply"></i>
            </button>
          </div>
        </div>
      `;
      timeline.appendChild(postDiv);
    });
  } catch (e) {
    console.error("投稿の読み込みエラー:", e);
    // エラー時はログインページへリダイレクト
    window.location.href = "index.html";
  }
}

// リプライ送信
async function submitReply(postId) {
  const replyInput = document.getElementById(`reply-input-${postId}`);
  const content = replyInput.value;
  if (!content) {
    alert("リプライ内容が空です");
    return;
  }
  if (!currentUser) {
    alert("ログインしていません");
    window.location.href = "index.html";
    return;
  }

  try {
    const res = await fetch(`/api/posts/${postId}/replies`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        userName: currentUser.name,
        content,
      }),
    });
    const data = await res.json();
    if (data.success) {
      replyInput.value = "";
      loadPosts();
    } else {
      alert("リプライに失敗しました: " + data.error);
    }
  } catch (e) {
    console.error("リプライ送信エラー:", e);
    alert("通信エラーが発生しました");
  }
}

// いいね処理
async function toggleLike(postId) {
  if (!currentUser) {
    alert("ログインしていません");
    window.location.href = "index.html";
    return;
  }
  try {
    const res = await fetch(`/api/posts/${postId}/likes`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ userName: currentUser.name }),
    });
    const data = await res.json();
    if (data.success) {
      loadPosts();
    } else {
      alert("いいね処理に失敗しました: " + data.error);
    }
  } catch (e) {
    console.error("いいね処理エラー:", e);
    alert("通信エラーが発生しました");
  }
}
