const express = require("express");
const router = express.Router();
const fs = require("fs"); // fs.promisesではなく、同期版のfsを使用
const path = require("path");

const USERS_FILE = path.join(__dirname, "../data/users.json");

// サーバー起動時に一度だけ実行
// ファイルがなければ作成
if (!fs.existsSync(USERS_FILE)) {
  try {
    fs.mkdirSync(path.dirname(USERS_FILE), { recursive: true });
    fs.writeFileSync(USERS_FILE, "[]");
    console.log("users.json created successfully.");
  } catch (e) {
    console.error("Error creating users.json:", e);
  }
}

/**
 * @api {post} /api/auth/login ログインまたは新規登録
 */
router.post("/login", (req, res) => {
  try {
    const { name, password } = req.body;
    if (!name || !password) {
      return res
        .status(400)
        .json({ success: false, error: "名前とパスワードが必要です" });
    }

    let users = [];
    try {
      const data = fs.readFileSync(USERS_FILE, "utf8");
      if (data) {
        users = JSON.parse(data);
      }
    } catch (e) {
      console.error("ユーザーデータ読み込みエラー:", e);
      // JSONのパース失敗時は空の配列で再開
      users = [];
    }

    let user = users.find((u) => u.name === name);

    if (!user) {
      // 新規登録
      const newUser = { id: Date.now(), name, password };
      users.push(newUser);
      fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));

      // セッションにユーザーIDを保存
      req.session.userId = newUser.id;

      // 新しい変数名に変更して、パスワードを返さないようにする
      const { password: _password, ...userWithoutPassword } = newUser;
      return res.json({ success: true, user: userWithoutPassword });
    } else {
      // ログイン処理
      if (user.password === password) {
        // セッションにユーザーIDを保存
        req.session.userId = user.id;

        // 新しい変数名に変更して、パスワードを返さないようにする
        const { password: _password, ...userWithoutPassword } = user;
        return res.json({ success: true, user: userWithoutPassword });
      } else {
        return res
          .status(401)
          .json({ success: false, error: "パスワードが違います" });
      }
    }
  } catch (e) {
    console.error("ログイン処理中にエラー発生:", e);
    res.status(500).json({ success: false, error: "サーバー内部エラー" });
  }
});

/**
 * @api {get} /api/auth/me 認証状態の確認
 */
router.get("/me", (req, res) => {
  try {
    const userId = req.session.userId;
    if (!userId) {
      return res.json({ success: false, error: "認証されていません" });
    }

    let users = [];
    try {
      const data = fs.readFileSync(USERS_FILE, "utf8");
      if (data) {
        users = JSON.parse(data);
      }
    } catch (e) {
      console.error("ユーザーデータ読み込みエラー:", e);
      return res
        .status(500)
        .json({ success: false, error: "サーバー内部エラー" });
    }

    const user = users.find((u) => u.id === userId);
    if (!user) {
      req.session.destroy();
      return res.json({ success: false, error: "ユーザーが見つかりません" });
    }

    const { password: _password, ...userWithoutPassword } = user;
    res.json({ success: true, user: userWithoutPassword });
  } catch (e) {
    console.error("認証状態確認中にエラー発生:", e);
    res.status(500).json({ success: false, error: "サーバー内部エラー" });
  }
});

/**
 * @api {post} /api/auth/logout ログアウト
 */
router.post("/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res
        .status(500)
        .json({ success: false, error: "ログアウトに失敗しました" });
    }
    res.json({ success: true });
  });
});

module.exports = router;
