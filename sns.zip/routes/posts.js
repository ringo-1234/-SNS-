// routes/posts.js (サーバー側)
const express = require("express");
const fs = require("fs");
const path = require("path");
const router = express.Router();

const POSTS_FILE = path.join(__dirname, "../data/posts.json");

// ファイルがなければ作成
if (!fs.existsSync(POSTS_FILE)) {
  fs.mkdirSync(path.dirname(POSTS_FILE), { recursive: true });
  fs.writeFileSync(POSTS_FILE, "[]");
}

// 簡易的な認証ミドルウェア
function requireLogin(req, res, next) {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({ success: false, error: "認証が必要です" });
  }
  next();
}

/**
 * @api {get} /api/posts 投稿一覧を取得
 */
router.get("/", (req, res) => {
  try {
    const posts = JSON.parse(fs.readFileSync(POSTS_FILE, "utf8"));
    res.json(posts);
  } catch (err) {
    console.error("投稿読み込みエラー:", err);
    res.status(500).json({ success: false, error: "読み込みエラー" });
  }
});

/**
 * @api {post} /api/posts 新しい投稿を保存
 */
router.post("/", requireLogin, (req, res) => {
  try {
    const { userName, content } = req.body;
    if (!userName || !content) {
      return res
        .status(400)
        .json({ success: false, error: "投稿内容が不正です" });
    }

    const posts = JSON.parse(fs.readFileSync(POSTS_FILE, "utf8"));
    const newPost = {
      id: Date.now(),
      userName,
      content,
      timestamp: new Date().toISOString(),
      replies: [],
      likes: [],
    };
    posts.push(newPost);
    fs.writeFileSync(POSTS_FILE, JSON.stringify(posts, null, 2));
    res.json({ success: true, post: newPost });
  } catch (err) {
    console.error("投稿保存エラー:", err);
    res.status(500).json({ success: false, error: "サーバー内部エラー" });
  }
});

/**
 * @api {post} /api/posts/:postId/replies 投稿にリプライを追加
 */
router.post("/:postId/replies", requireLogin, (req, res) => {
  try {
    const { postId } = req.params;
    const { userName, content } = req.body;
    if (!userName || !content) {
      return res
        .status(400)
        .json({ success: false, error: "リプライ内容が不正です" });
    }

    const posts = JSON.parse(fs.readFileSync(POSTS_FILE, "utf8"));
    const postIndex = posts.findIndex((p) => p.id === parseInt(postId));

    if (postIndex === -1) {
      return res
        .status(404)
        .json({ success: false, error: "投稿が見つかりません" });
    }

    posts[postIndex].replies.push({
      userName,
      content,
      timestamp: new Date().toISOString(),
    });

    fs.writeFileSync(POSTS_FILE, JSON.stringify(posts, null, 2));
    res.json({ success: true });
  } catch (err) {
    console.error("リプライ保存エラー:", err);
    res.status(500).json({ success: false, error: "サーバー内部エラー" });
  }
});

/**
 * @api {post} /api/posts/:postId/likes 投稿に「いいね」を追加/削除
 */
router.post("/:postId/likes", requireLogin, (req, res) => {
  try {
    const { postId } = req.params;
    const { userName } = req.body;

    const posts = JSON.parse(fs.readFileSync(POSTS_FILE, "utf8"));
    const postIndex = posts.findIndex((p) => p.id === parseInt(postId));

    if (postIndex === -1) {
      return res
        .status(404)
        .json({ success: false, error: "投稿が見つかりません" });
    }

    const likes = posts[postIndex].likes;
    const existingLikeIndex = likes.indexOf(userName);

    if (existingLikeIndex > -1) {
      // 既存のいいねを削除
      likes.splice(existingLikeIndex, 1);
    } else {
      // 新しいいいねを追加
      likes.push(userName);
    }

    fs.writeFileSync(POSTS_FILE, JSON.stringify(posts, null, 2));
    res.json({ success: true, likes: likes.length });
  } catch (err) {
    console.error("いいね処理エラー:", err);
    res.status(500).json({ success: false, error: "サーバー内部エラー" });
  }
});

module.exports = router;
